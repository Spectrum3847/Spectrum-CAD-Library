
EN   Your CAD data on 29.12.2016 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 8042548 VUVG-LK10-B52-T-M7-1H2L-S 
    
    X_B, 8042548 VUVG-LK10-B52-T-M7-1H2L-S, 8042548_VUVG-LK10-B52-T-M7-1H2L-S.x_b
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    
