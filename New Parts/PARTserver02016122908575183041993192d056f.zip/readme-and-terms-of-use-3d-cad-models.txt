
EN   Your CAD data on 29.12.2016 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 566654 NEBV-H1G2-KN-0.5-N-LE2 
    
    X_B, 566654 NEBV-H1G2-KN-0.5-N-LE2, 566654_NEBV-H1G2-KN-0_5-N-LE2.x_b
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    
